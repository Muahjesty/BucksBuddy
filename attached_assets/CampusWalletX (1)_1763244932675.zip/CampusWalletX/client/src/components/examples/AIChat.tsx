import AIChat from '../AIChat';

export default function AIChatExample() {
  return (
    <div className="p-4 max-w-2xl mx-auto">
      <AIChat />
    </div>
  );
}
